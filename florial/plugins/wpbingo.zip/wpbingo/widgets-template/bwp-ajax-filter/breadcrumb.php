<?php
	set_query_var('paged', false);
	florial_woocommerce_breadcrumb();
?>